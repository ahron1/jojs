	document.addEventListener("DOMContentLoaded", function(event) { 
		on_page_load();
	});
function on_page_load() {
	// send empty GET to check for cookies
	var xhr = new XMLHttpRequest;
	xhr.open('GET', server);
	xhr.onload = function() {
		if (xhr.status === 200) {
			overlay_off();
				}
		else if (xhr.status !== 200) {
			overlay_on();
				}
	};
	xhr.send();
}
function sign_in() {
	alert(document.getElementById("login-email").value);	
	var xhr = new XMLHttpRequest;
	xhr.open('POST', server);
	xhr.onload = function() {
	  alert(this.response);
		if (xhr.status === 200) {
			//alert('Something went wrong.  Name is now ' + xhr.responseText);
			overlay_off();
				}
		else if (xhr.status !== 200) {
			//alert('Request failed.  Returned status of ' + xhr.status);
				}
	};
	var data = JSON.stringify({login:document.getElementById("login-email").value,password:document.getElementById("login-password").value});
	alert("sign in with: " + data);
	xhr.send(data);
}
function check_passwords_match(){
	var password1 = document.getElementById("login-password").value;
	var password2 = document.getElementById("login-password-repeat").value;
	if (password1 != "" && password2 == password1){
		return 0;
	} 
	else {
		return 1;
	}
}
//to do
function join_waiting_list() {
	if (check_passwords_match() == 0){
		alert('passwords match');
		var xhr = new XMLHttpRequest;
		xhr.open('POST', server);
		xhr.onload = function() {
		  alert(this.response);
			if (xhr.status === 200) {
				alert('Request successful. You will be invited soon...' + xhr.responseText);
				//overlay_off();
					}
			else if (xhr.status !== 200) {
				alert('Request failed.  Returned status of ' + xhr.status);
					}
		};
		var data = JSON.stringify({login:document.getElementById("login-email").value,password:document.getElementById("login-password").value});
		alert("join waiting list with: " + data);
		xhr.send(data);
		location.reload(true);
	} 
	else {
		alert('please retry the password');
		document.getElementById("login-password-repeat").value = "";
		document.getElementById("login-password").value = "";
	}
}
//to do 
function sign_up_now() {
	alert(document.getElementById("login-email").value);	
	var xhr = new XMLHttpRequest;
	xhr.open('POST', server);
	xhr.onload = function() {
	  alert(this.response);
		if (xhr.status === 200) {
			//alert('Something went wrong.  Name is now ' + xhr.responseText);
			overlay_off();
				}
		else if (xhr.status !== 200) {
			//alert('Request failed.  Returned status of ' + xhr.status);
				}
	};
	var data = JSON.stringify({login:document.getElementById("login-email").value,password:document.getElementById("login-password").value});
	alert(data);
	xhr.send(data);
}
function overlay_off(){
document.getElementById("overlay").style.display = "none";
}
function show_signup(){
document.getElementById("repeatpassword").style.display = "block";
document.getElementById("signupwithinvitation").style.display = "block";
document.getElementById("joinwaitinglistbutton").style.display = "block";
document.getElementById("sign-up").style.display = "block";
document.getElementById("loginbutton").style.display = "none";
document.getElementById("signupbutton").style.display = "none";
document.getElementById("no-account-text").style.display = "none";
}
function overlay_on(){
document.getElementById("overlay").style.display = "block";
document.getElementById("repeatpassword").style.display = "none";
document.getElementById("signupwithinvitation").style.display = "none";
document.getElementById("joinwaitinglistbutton").style.display = "none";
document.getElementById("sign-up").style.display = "none";
}
//global variables to be moved to scoping function
server = "/cowboy";
n = 0;
images_list = ["./images/2.jpg", "./images/3.jpg", "./images/4.jpg", "./images/5.jpg"];
image_titles_list = ["foo", "bar", "baz", "fab"];
images_list_length = images_list.length;
image_titles_list_length = image_titles_list.length;

function nextimage(clickedbuttonid) {
	alert(n + '\n' + clickedbuttonid + '\n' + document.getElementById("imagetitle").innerHTML);
	document.getElementById("currentimage").src = images_list[n % images_list_length];
	document.getElementById("imagetitle").innerHTML = image_titles_list[n % image_titles_list_length];
	n = n + 1;
	make_ajax_call(server);
	//function to simply update images_list with this.response. 
}
function ajaxcallback(serverrespos) {
	var server_response = JSON.parse(this.response);
	alert(server_response);
	//var myarray = JSON.parse(this.response);
	//alert(myarray);
	alert(this.response);
	//images_list = JSON.parse(this.response);
}
function make_ajax_call(URL) {
	var xhr = new XMLHttpRequest;
	xhr.open('POST', URL);
	xhr.onload = function(e) {
		alert(this.response);
	};
	xhr.send("foo");
}
function sendmessage() {
	var xhr = new XMLHttpRequest;
	xhr.open('POST', server);
	xhr.onload = function() {
	  alert(this.response);
	  alert("thank you, message received");
	};
	var data = JSON.stringify({name:document.getElementById("text-name").value,email:document.getElementById("text-email").value,message:document.getElementById("textarea-message").value});
	alert(data);
	xhr.send(data);

//			alert(document.getElementById("text-name").value);
//			alert(document.getElementById("text-email").value);
//			alert(document.getElementById("textarea-message").value);
}	
